import React from 'react';
import ThemeToggle from './components/ThemeToggle';

function App() {
  return (
    <div>
      <ThemeToggle />
    </div>
  );
}

export default App;

