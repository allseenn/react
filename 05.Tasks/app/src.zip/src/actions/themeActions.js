export const TOGGLE_THEME = 'TOGGLE_THEME';

export const toggleTheme = () => {
  return {
    type: TOGGLE_THEME,
  };
};
